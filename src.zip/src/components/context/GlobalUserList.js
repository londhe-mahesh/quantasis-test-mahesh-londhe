import React from 'react'

const GlobalUserList = React.createContext([{}, ()=>{}])

export default GlobalUserList